import type {Order} from "@/api/model/order.ts";
import {OrderStatus} from "@/api/model/order.ts";
import type {OrderItem, OrderItemModifier} from "@/api/model/order_item.ts";
import type {OrderVoid} from "@/api/model/order_void.ts";
import {recordIdToString} from "@/api/reports/shared/records.ts";
import type {
  CategoryGroup,
  ModifierDetail,
  ModifierSummaryMetrics,
  OrderFigures,
  ProductMixFilters,
  SalesSummaryResult,
  TopSellingDish,
} from "@/api/reports/shared/types.ts";
import {calculateOrderItemPrice} from "@/lib/cart.ts";
import {getOrderItemTaxAmount, getOrderTaxAmount} from "@/lib/tax-calculator.ts";
import {getOrderItemDisplayLineTotal, getOrderItemModifierDisplayPrice} from "@/lib/order-item-display.ts";
import {toJsDate} from "@/lib/datetime.ts";
import {getOrderAmountDueFromPayments, getOrderFilteredItems, getOrderPaymentTotals, getOrderRounding, getOrderCartDiscountAmount, getOrderLineDiscountTotal, getOrderSettlementFigures, calculateOrderNetSales, aggregateOrderDiscountBreakdown} from "@/lib/order.ts";
import {safeNumber} from "@/lib/utils.ts";
import {DAY_PARTS, getDayPartLabel, type DayPartLabel} from "@/utils/dayParts";

/** Modifier row shape used by Daily Sales Summary / Product Mix Summary (summary-style). */
export type DailyCategoryMixModifier = {
  name: string;
  depth: number;
  path: string;
  quantity: number;
  price: number;
};

export type DailyCategoryMixDish = {
  key: string;
  name: string;
  modifiers: DailyCategoryMixModifier[];
  total: number;
  quantity: number;
};

export type DailyCategoryMixCategory = {
  name: string;
  total: number;
  quantity: number;
  dishes: DailyCategoryMixDish[];
};

export const getOrderFigures = (order: Order): OrderFigures => {
  const filteredItems = getOrderFilteredItems(order) ?? [];
  const exclusiveSales = filteredItems.reduce((sum, item) => sum + safeNumber(calculateOrderItemPrice(item)), 0);
  const extras = (order.extras ?? []).reduce((sum, extra) => sum + safeNumber(extra?.value), 0);
  const grossSales = safeNumber(exclusiveSales + extras);

  const lineDiscounts = getOrderLineDiscountTotal(order);
  const orderDiscount = getOrderCartDiscountAmount(order);
  const subtotalDiscount = Math.max(0, orderDiscount - lineDiscounts);
  const couponDiscount = safeNumber(order.coupon?.discount);
  const discounts = safeNumber(lineDiscounts + subtotalDiscount + couponDiscount);
  const netSales = safeNumber(grossSales - discounts);

  const serviceCharge = safeNumber(order.service_charge_amount);
  const tax = getOrderTaxAmount(order);
  const tips = safeNumber(order.tip_amount);
  const totalRevenue = safeNumber(netSales + serviceCharge + tax);
  const grandTotal = safeNumber(totalRevenue + tips);

  const allItems = order.items ?? [];
  const voidedItems = allItems.filter(item => !filteredItems.some(filtered => filtered.id === item.id));
  const voidAmount = voidedItems.reduce((sum, item) => sum + safeNumber(calculateOrderItemPrice(item)), 0);

  const hasRefundPayment = (order.payments ?? []).some(payment => safeNumber(payment.amount) < 0);
  const isRefundedOrder = order.status === OrderStatus.Refunded
    || order.status === OrderStatus.Cancelled
    || hasRefundPayment;

  return {
    exclusiveSales,
    grossSales,
    discounts,
    netSales,
    serviceCharge,
    tax,
    tips,
    totalRevenue,
    grandTotal,
    couponDiscount,
    voidAmount,
    isRefundedOrder,
  };
};

export {calculateOrderNetSales} from "@/lib/order.ts";

const calculateOrderAmountDue = (order: Order): number => {
  return getOrderAmountDueFromPayments(order);
};

const calculateVoidEntryAmount = (entry: OrderVoid): number => {
  const quantity = safeNumber(entry?.quantity || 1);
  const voidItems = (entry?.items ?? []).filter(Boolean);
  return voidItems.reduce((sum, item) => {
    const lineAmount = calculateOrderItemPrice({
      ...(item ?? {}),
      quantity,
    } as Parameters<typeof calculateOrderItemPrice>[0]);
    return sum + safeNumber(lineAmount);
  }, 0);
};

const collectCategories = (item: {item?: {categories?: unknown[]; name?: string}; category?: string}) => {
  if (!item?.item) {
    return [{id: "uncategorized", name: "Uncategorized"}];
  }

  const categories = item.item?.categories || [];
  if (Array.isArray(categories) && categories.length > 0) {
    return categories
      .map((cat: unknown) => ({
        id: recordIdToString(cat),
        name: (cat as {name?: string})?.name ?? "Uncategorized",
      }))
      .filter(cat => Boolean(cat.id));
  }

  if (item.category) {
    return [{id: item.category, name: item.category}];
  }

  return [{id: "uncategorized", name: "Uncategorized"}];
};

const filterOrdersByProductMix = (orders: Order[], filters: ProductMixFilters = {}) => {
  const categoryIds = filters.categoryIds ?? [];
  const menuItemIds = filters.menuItemIds ?? [];

  return orders.filter(order => {
    if (categoryIds.length > 0) {
      const hasMatchingCategory = order.items?.some(item => {
        const itemCategories = item.item?.categories || [];
        if (Array.isArray(itemCategories)) {
          return itemCategories.some((cat: unknown) => {
            const catId = recordIdToString(cat);
            return catId && categoryIds.includes(catId);
          });
        }
        return false;
      });
      if (!hasMatchingCategory) return false;
    }

    if (menuItemIds.length > 0) {
      const hasMatchingMenuItem = order.items?.some(item => {
        const itemId = recordIdToString(item.item);
        return itemId && menuItemIds.includes(itemId);
      });
      if (!hasMatchingMenuItem) return false;
    }

    return true;
  });
};

const getFilteredOrderItems = (order: Order, filters: ProductMixFilters = {}) => {
  const categoryIds = filters.categoryIds ?? [];
  const menuItemIds = filters.menuItemIds ?? [];

  return getOrderFilteredItems(order)?.filter(item => {
    if (categoryIds.length > 0) {
      const itemCategories = item.item?.categories || [];
      const hasMatchingCategory = Array.isArray(itemCategories)
        ? itemCategories.some((cat: unknown) => {
          const catId = recordIdToString(cat);
          return catId && categoryIds.includes(catId);
        })
        : false;
      if (!hasMatchingCategory) return false;
    }

    if (menuItemIds.length > 0) {
      const itemId = recordIdToString(item.item);
      if (!itemId || !menuItemIds.includes(itemId)) return false;
    }

    return true;
  }) || [];
};

export const aggregateTopSellingDishes = (
  orders: Order[],
  options: {limit?: number; sortBy?: "quantity" | "revenue"} = {},
): TopSellingDish[] => {
  const {limit, sortBy = "revenue"} = options;
  const map = new Map<string, TopSellingDish>();

  orders.forEach(order => {
    getOrderFilteredItems(order).forEach(item => {
      const dishId = recordIdToString(item.item?.id);
      const name = item.item?.name || "Unknown";
      const key = dishId || name;
      const current = map.get(key) || {dishId: dishId || undefined, name, quantity: 0, revenue: 0};
      current.quantity += safeNumber(item.quantity ?? 1);
      current.revenue += calculateOrderItemPrice(item);
      map.set(key, current);
    });
  });

  const sorted = Array.from(map.values()).sort((a, b) => {
    if (sortBy === "quantity") {
      return b.quantity - a.quantity;
    }
    return b.revenue - a.revenue;
  });

  return limit ? sorted.slice(0, limit) : sorted;
};

export const aggregateSalesSummary = (orders: Order[], orderVoids: OrderVoid[]): SalesSummaryResult => {
  const totalNetSales = orders.reduce((sum, order) => sum + calculateOrderNetSales(order), 0);

  const paymentSummary = orders.reduce(
    (acc, order) => {
      acc.amountDue += calculateOrderAmountDue(order);
      const paymentTotals = getOrderPaymentTotals(order);
      acc.amountCollected += paymentTotals.amountCollected;
      acc.cashPayments += paymentTotals.cashAmount;
      acc.nonCashPayments += paymentTotals.nonCashAmount;
      Object.entries(paymentTotals.nonCashBreakdown).forEach(([typeName, amount]) => {
        acc.nonCashBreakdown[typeName] = (acc.nonCashBreakdown[typeName] ?? 0) + amount;
      });
      return acc;
    },
    {
      amountDue: 0,
      amountCollected: 0,
      cashPayments: 0,
      nonCashPayments: 0,
      nonCashBreakdown: {} as Record<string, number>,
    },
  );

  const roundingBenefit = orders.reduce((sum, order) => sum - getOrderRounding(order), 0);
  const serviceCharges = orders.reduce((sum, order) => sum + safeNumber(order.service_charge_amount), 0);
  
  const taxes = orders.reduce((sum, order) => sum + getOrderTaxAmount(order), 0);
  
  const totalDiscounts = orders.reduce((sum, order) => sum + getOrderFigures(order).discounts, 0);
  const totalCoupons = orders.reduce((sum, order) => sum + safeNumber(order.coupon?.discount), 0);

  const dayPartTotals = DAY_PARTS.reduce(
    (acc, part) => ({
      ...acc,
      [part.label]: {checks: 0, guests: 0, sales: 0},
    }),
    {} as Record<DayPartLabel, {checks: number; guests: number; sales: number}>,
  );

  orders.forEach(order => {
    const label = getDayPartLabel(toJsDate(order.created_at));
    dayPartTotals[label].checks += 1;
    dayPartTotals[label].guests += safeNumber(order.covers);
    dayPartTotals[label].sales += calculateOrderNetSales(order);
  });

  const orderTypeMap = new Map<string, number>();
  orders.forEach(order => {
    const key = order.order_type?.name || (typeof order.order_type === "string" ? order.order_type : "Unknown");
    orderTypeMap.set(key, (orderTypeMap.get(key) ?? 0) + calculateOrderNetSales(order));
  });

  const orderTypeBreakdown = Array.from(orderTypeMap.entries())
    .map(([label, value]) => ({label, value}))
    .sort((a, b) => b.value - a.value);

  const totalVoids = orderVoids.reduce((sum, entry) => sum + calculateVoidEntryAmount(entry), 0);

  const discountRows = aggregateOrderDiscountBreakdown(orders, 'name').map(row => ({
    type: row.rateLabel !== '-' ? `${row.name} (${row.rateLabel})` : row.name,
    quantity: row.quantity,
    amount: row.total,
  }));

  return {
    totalNetSales,
    paymentSummary,
    roundingBenefit,
    serviceCharges,
    taxes,
    totalDiscounts,
    totalCoupons,
    totalVoids,
    dayPartTotals,
    orderTypeBreakdown,
    discountRows,
  };
};

const MODIFIER_WALK_MAX_DEPTH = 32;

const toPriceKey = (value: number) => safeNumber(value).toFixed(4);

// Modifiers are grouped by what the user perceives as "the same modifier":
// identical name, nesting level and unit price. The underlying dish record id
// is intentionally not part of the key, since the same modifier can be backed
// by different dish records that share a name.
const buildModifierMergeKey = (name: string, depth: number, unitPrice: number) =>
  `${name.trim().toLowerCase()}|${depth}|${toPriceKey(unitPrice)}`;

const buildModifierAccumulatedKey = (name: string) => name.trim().toLowerCase();

interface WalkedModifier {
  modifierId: string;
  modifierName: string;
  depth: number;
  quantity: number;
  price: number;
}

// Depth-first walk of the embedded modifier tree. Each selected modifier nests
// further groups under `selectedGroups`, so we recurse to any depth (guarded by
// MODIFIER_WALK_MAX_DEPTH) yielding one node per selected modifier.
const walkSelectedModifiers = (
  modifierGroups: OrderItemModifier[] | undefined,
  depth = 1,
  parentItem?: OrderItem,
  showInclusivePrices = false,
): WalkedModifier[] => {
  const results: WalkedModifier[] = [];

  if (!Array.isArray(modifierGroups) || depth > MODIFIER_WALK_MAX_DEPTH) {
    return results;
  }

  modifierGroups.forEach(group => {
    const selectedModifiers = group?.selectedModifiers;
    if (!Array.isArray(selectedModifiers)) return;

    selectedModifiers.forEach(selectedModifier => {
      if (!selectedModifier) return;

      // Pass the whole dish (not dish.id) so RecordId values resolve to the full
      // "table:id" string. recordIdToString(dish.id) would drop the table prefix,
      // breaking equality with the modifier filter values (full record ids).
      const modifierId = recordIdToString(selectedModifier.dish);
      const modifierName = selectedModifier.dish?.name
        || (selectedModifier as {name?: string}).name
        || "Unknown";
      const quantity = safeNumber(selectedModifier.quantity || 1);
      const rawPrice = safeNumber(selectedModifier.price || 0);
      const price = parentItem
        ? getOrderItemModifierDisplayPrice(rawPrice, parentItem, showInclusivePrices)
        : rawPrice;

      results.push({modifierId, modifierName, depth, quantity, price});
      results.push(...walkSelectedModifiers(
        selectedModifier.selectedGroups,
        depth + 1,
        parentItem,
        showInclusivePrices,
      ));
    });
  });

  return results;
};

export const aggregateProductMixByCategory = (
  orders: Order[],
  filters: ProductMixFilters = {},
): CategoryGroup[] => {
  const filteredOrders = filterOrdersByProductMix(orders, filters);
  const dishMap = new Map<string, {
    dishId: string;
    itemNumber: string;
    name: string;
    categoryId: string;
    categoryName: string;
    numSold: number;
    totalAmount: number;
    totalCost: number;
    discount: number;
    tax: number;
    serviceCharges: number;
    totalCollected: number;
    baseDishTotal: number;
    hasModifiers: boolean;
    modifiers: Map<string, ModifierDetail>;
  }>();

  filteredOrders.forEach(order => {
    getFilteredOrderItems(order, filters).forEach(item => {
      if (!item.item) return;

      const dishId = recordIdToString(item.item.id);
      const itemNumber = item.item.number || "";
      const name = item.item.name || "Unknown";
      const categories = collectCategories(item);
      const quantity = safeNumber(item.quantity);
      const netAmount = safeNumber(calculateOrderItemPrice(item));
      const amount = filters.showInclusivePrices
        ? safeNumber(getOrderItemDisplayLineTotal(item, true))
        : netAmount;
      const cost = safeNumber(item.item.cost || 0);
      const totalCost = cost * quantity;

      const discount = safeNumber(item.discount || 0);
      const tax = getOrderItemTaxAmount(item, order);
      const serviceCharges = safeNumber(item.service_charges || 0);
      const baseDishPrice = safeNumber(item.price || 0) * quantity;
      const total = safeNumber(netAmount + tax + serviceCharges - discount);
      const baseDishTotal = safeNumber(baseDishPrice + tax + serviceCharges - discount);

      const walkedModifiers = walkSelectedModifiers(
        item.modifiers,
        1,
        item,
        !!filters.showInclusivePrices,
      );
      const modifierTotal = walkedModifiers
        .filter(modifier => modifier.depth === 1)
        .reduce((sum, modifier) => sum + modifier.price, 0);
      const totalCollected = safeNumber(total + modifierTotal);

      categories.forEach(category => {
        const key = `${category.id}-${dishId}`;
        const existing = dishMap.get(key) || {
          dishId,
          itemNumber,
          name,
          categoryId: category.id,
          categoryName: category.name,
          numSold: 0,
          totalAmount: 0,
          totalCost: 0,
          discount: 0,
          tax: 0,
          serviceCharges: 0,
          totalCollected: 0,
          baseDishTotal: 0,
          hasModifiers: false,
          modifiers: new Map<string, ModifierDetail>(),
        };

        existing.numSold += quantity;
        existing.totalAmount += amount;
        existing.totalCost += totalCost;
        existing.discount += discount;
        existing.tax += tax;
        existing.serviceCharges += serviceCharges;
        existing.totalCollected += totalCollected;
        existing.baseDishTotal += baseDishTotal;
        existing.hasModifiers = existing.hasModifiers || walkedModifiers.length > 0;

        walkedModifiers.forEach(modifier => {
          const unitPrice = modifier.quantity > 0 ? modifier.price / modifier.quantity : modifier.price;
          const modifierKey = buildModifierMergeKey(modifier.modifierName, modifier.depth, unitPrice);
          const existingModifier = existing.modifiers.get(modifierKey);

          if (existingModifier) {
            existingModifier.quantity += modifier.quantity;
            existingModifier.total += modifier.price;
          } else {
            existing.modifiers.set(modifierKey, {
              modifierKey,
              modifierId: modifier.modifierId,
              modifierName: modifier.modifierName,
              depth: modifier.depth,
              quantity: modifier.quantity,
              unitPrice,
              discount: 0,
              tax: 0,
              serviceCharges: 0,
              total: modifier.price,
              ratio: 0,
              mealPrice: 0,
            });
          }
        });

        dishMap.set(key, existing);
      });
    });
  });

  const categoryMap = new Map<string, CategoryGroup>();

  dishMap.forEach((dishData) => {
    if (!categoryMap.has(dishData.categoryId)) {
      categoryMap.set(dishData.categoryId, {
        categoryId: dishData.categoryId,
        categoryName: dishData.categoryName,
        items: [],
        totals: {
          numSold: 0,
          priceSold: 0,
          amount: 0,
          cost: 0,
          profit: 0,
          foodCostPercent: 0,
          salePercent: 0,
          discount: 0,
          tax: 0,
          serviceCharges: 0,
          totalCollected: 0,
        },
      });
    }

    const category = categoryMap.get(dishData.categoryId)!;
    const priceSold = dishData.numSold > 0 ? dishData.totalAmount / dishData.numSold : 0;
    const profit = dishData.totalAmount - dishData.totalCost;
    const foodCostPercent = dishData.totalAmount > 0
      ? (dishData.totalCost / dishData.totalAmount) * 100
      : 0;

    const modifiers = Array.from(dishData.modifiers.values()).map(modifier => {
      const unitPrice = modifier.quantity > 0 ? safeNumber(modifier.total / modifier.quantity) : 0;
      const ratio = dishData.baseDishTotal > 0 ? safeNumber(modifier.total / dishData.baseDishTotal) : 0;
      const mealPrice = safeNumber(dishData.baseDishTotal + modifier.total);

      return {
        ...modifier,
        unitPrice,
        ratio,
        mealPrice,
      };
    }).sort((a, b) => {
      if (a.depth !== b.depth) {
        return a.depth - b.depth;
      }
      const nameCompare = a.modifierName.localeCompare(b.modifierName);
      if (nameCompare !== 0) {
        return nameCompare;
      }
      return a.unitPrice - b.unitPrice;
    });

    category.items.push({
      dishId: dishData.dishId,
      itemNumber: dishData.itemNumber,
      name: dishData.name,
      numSold: dishData.numSold,
      priceSold,
      amount: dishData.totalAmount,
      cost: dishData.totalCost,
      profit,
      foodCostPercent,
      salePercent: 0,
      discount: dishData.discount,
      tax: dishData.tax,
      serviceCharges: dishData.serviceCharges,
      totalCollected: dishData.totalCollected,
      hasModifiers: dishData.hasModifiers,
      modifiers,
    });
  });

  const totalSales = Array.from(categoryMap.values()).reduce(
    (sum, cat) => sum + cat.items.reduce((s, item) => s + item.amount, 0),
    0,
  );

  categoryMap.forEach((category) => {
    category.items.sort((a, b) => b.amount - a.amount);
    category.items.forEach((item) => {
      item.salePercent = totalSales > 0 ? (item.amount / totalSales) * 100 : 0;
    });

    category.totals = category.items.reduce(
      (acc, item) => ({
        numSold: acc.numSold + item.numSold,
        priceSold: 0,
        amount: acc.amount + item.amount,
        cost: acc.cost + item.cost,
        profit: acc.profit + item.profit,
        foodCostPercent: 0,
        salePercent: acc.salePercent + item.salePercent,
        discount: acc.discount + item.discount,
        tax: acc.tax + item.tax,
        serviceCharges: acc.serviceCharges + item.serviceCharges,
        totalCollected: acc.totalCollected + item.totalCollected,
      }),
      {
        numSold: 0,
        priceSold: 0,
        amount: 0,
        cost: 0,
        profit: 0,
        foodCostPercent: 0,
        salePercent: 0,
        discount: 0,
        tax: 0,
        serviceCharges: 0,
        totalCollected: 0,
      },
    );

    category.totals.priceSold = category.totals.numSold > 0
      ? category.totals.amount / category.totals.numSold
      : 0;
    category.totals.foodCostPercent = category.totals.amount > 0
      ? (category.totals.cost / category.totals.amount) * 100
      : 0;
  });

  return Array.from(categoryMap.values()).sort((a, b) => b.totals.amount - a.totals.amount);
};

export const aggregateModifiersSummary = (
  orders: Order[],
  filters: ProductMixFilters = {},
): ModifierSummaryMetrics[] => {
  const filteredOrders = filterOrdersByProductMix(orders, filters);
  const selectedModifierIds = new Set(filters.modifierIds ?? []);
  const summaryMap = new Map<string, ModifierSummaryMetrics>();

  filteredOrders.forEach(order => {
    getFilteredOrderItems(order, filters).forEach(item => {
      if (!item.item) return;

      walkSelectedModifiers(item.modifiers, 1, item, !!filters.showInclusivePrices).forEach(modifier => {
        if (selectedModifierIds.size > 0 && !selectedModifierIds.has(modifier.modifierId)) {
          return;
        }

        const unitPrice = modifier.quantity > 0 ? safeNumber(modifier.price / modifier.quantity) : safeNumber(modifier.price);
        const rowKey = buildModifierMergeKey(modifier.modifierName, modifier.depth, unitPrice);
        const existing = summaryMap.get(rowKey) || {
          rowKey,
          modifierId: modifier.modifierId,
          modifierName: modifier.modifierName,
          depth: modifier.depth,
          quantity: 0,
          unitPrice,
          total: 0,
        };

        existing.quantity += modifier.quantity;
        existing.total += modifier.price;
        existing.unitPrice = existing.quantity > 0 ? safeNumber(existing.total / existing.quantity) : 0;
        summaryMap.set(rowKey, existing);
      });
    });
  });

  return Array.from(summaryMap.values()).sort((a, b) => {
    const nameCompare = a.modifierName.localeCompare(b.modifierName);
    if (nameCompare !== 0) {
      return nameCompare;
    }
    if (a.depth !== b.depth) {
      return a.depth - b.depth;
    }
    return a.unitPrice - b.unitPrice;
  });
};

export const aggregateAccumulatedModifiersSummary = (
  orders: Order[],
  filters: ProductMixFilters = {},
): ModifierSummaryMetrics[] => {
  const filteredOrders = filterOrdersByProductMix(orders, filters);
  const selectedModifierIds = new Set(filters.modifierIds ?? []);
  const summaryMap = new Map<string, ModifierSummaryMetrics>();

  filteredOrders.forEach(order => {
    getFilteredOrderItems(order, filters).forEach(item => {
      if (!item.item) return;

      walkSelectedModifiers(item.modifiers, 1, item, !!filters.showInclusivePrices).forEach(modifier => {
        if (selectedModifierIds.size > 0 && !selectedModifierIds.has(modifier.modifierId)) {
          return;
        }

        const rowKey = buildModifierAccumulatedKey(modifier.modifierName);
        const existing = summaryMap.get(rowKey) || {
          rowKey,
          modifierId: modifier.modifierId,
          modifierName: modifier.modifierName,
          depth: 1,
          quantity: 0,
          unitPrice: 0,
          total: 0,
        };

        existing.quantity += modifier.quantity;
        existing.total += modifier.price;
        existing.unitPrice = existing.quantity > 0 ? safeNumber(existing.total / existing.quantity) : 0;
        summaryMap.set(rowKey, existing);
      });
    });
  });

  return Array.from(summaryMap.values()).sort((a, b) =>
    a.modifierName.localeCompare(b.modifierName),
  );
};

/**
 * Walk modifier groups the same way as Daily Sales Summary product mix
 * (name/path/depth + raw selected.price; quantity filled by the caller).
 */
export const getOrderItemModifierRows = (modifiers: any[] = []): DailyCategoryMixModifier[] => {
  const rows: DailyCategoryMixModifier[] = [];

  const walkGroups = (groups: any[] = [], depth = 1, parentPath = "") => {
    groups.forEach(group => {
      (group?.selectedModifiers ?? []).forEach((selected: any) => {
        const modifierName = String(selected?.dish?.name || selected?.name || "").trim();
        if (!modifierName) {
          return;
        }

        const currentPath = parentPath ? `${parentPath}>${modifierName}` : modifierName;
        rows.push({
          name: modifierName,
          depth,
          path: currentPath,
          quantity: 0,
          price: selected.price,
        });
        walkGroups(selected?.selectedGroups ?? [], depth + 1, currentPath);
      });
    });
  };

  walkGroups(modifiers);
  return rows;
};

type DailyCategoryMixAggregate = {
  total: number;
  quantity: number;
  dishes: Record<string, {
    name: string;
    modifiers: Record<string, DailyCategoryMixModifier>;
    total: number;
    quantity: number;
  }>;
};

/**
 * Category → dish → modifier mix matching Daily Sales Summary
 * (`item.category`, dish keyed by name, amount = calculateOrderItemPrice).
 */
export const aggregateDailyCategoryMix = (
  orders: Order[],
  options: {
    filters?: ProductMixFilters;
    uncategorizedLabel?: string;
    unknownItemLabel?: string;
  } = {},
): DailyCategoryMixCategory[] => {
  const filters = options.filters ?? {};
  const uncategorizedLabel = options.uncategorizedLabel ?? "Uncategorized";
  const unknownItemLabel = options.unknownItemLabel ?? "Unknown item";
  const selectedModifierIds = new Set(filters.modifierIds ?? []);
  const categoryMixMap: Record<string, DailyCategoryMixAggregate> = {};

  filterOrdersByProductMix(orders, filters).forEach(order => {
    getFilteredOrderItems(order, filters).forEach(item => {
      if (selectedModifierIds.size > 0) {
        const hasMatchingModifier = walkSelectedModifiers(item.modifiers, 1, item, false)
          .some(modifier => selectedModifierIds.has(modifier.modifierId));
        if (!hasMatchingModifier) {
          return;
        }
      }

      const categoryName = String(item?.category || uncategorizedLabel);
      const dishName = String(item?.item?.name || unknownItemLabel);
      const itemTotal = safeNumber(calculateOrderItemPrice(item));
      const itemQuantity = safeNumber(item?.quantity);
      const modifiers = getOrderItemModifierRows(item?.modifiers ?? []);
      const dishKey = dishName;

      if (!categoryMixMap[categoryName]) {
        categoryMixMap[categoryName] = {
          total: 0,
          quantity: 0,
          dishes: {},
        };
      }
      const category = categoryMixMap[categoryName];

      if (!category.dishes[dishKey]) {
        category.dishes[dishKey] = {
          name: dishName,
          modifiers: {},
          total: 0,
          quantity: 0,
        };
      }

      category.total += itemTotal;
      category.quantity += itemQuantity;
      category.dishes[dishKey].total += itemTotal;
      category.dishes[dishKey].quantity += itemQuantity;
      modifiers.forEach(modifier => {
        if (!category.dishes[dishKey].modifiers[modifier.path]) {
          category.dishes[dishKey].modifiers[modifier.path] = {
            ...modifier,
            quantity: 0,
          };
        }
        category.dishes[dishKey].modifiers[modifier.path].quantity += itemQuantity;
      });
    });
  });

  return Object.entries(categoryMixMap)
    .map(([name, category]) => {
      const dishes = Object.entries(category.dishes)
        .map(([key, dish]) => ({
          key,
          ...dish,
          modifiers: Object.values(dish.modifiers).sort((a, b) => a.path.localeCompare(b.path)),
        }))
        .sort((a, b) => b.total - a.total);
      return {
        name,
        total: category.total,
        quantity: category.quantity,
        dishes,
      };
    })
    .sort((a, b) => b.total - a.total);
};

/** Exclusive sales denominator for share % — same basis as Daily Sales Summary. */
export const sumOrdersExclusiveSales = (orders: Order[]): number =>
  orders.reduce((sum, order) => sum + getOrderSettlementFigures(order).itemsTotal, 0);

/**
 * Exclusive sales for a filtered product-mix set: sum of line prices on items
 * that participate in the mix (matches Daily when filters are empty).
 */
export const sumFilteredExclusiveSales = (
  orders: Order[],
  filters: ProductMixFilters = {},
): number => {
  const selectedModifierIds = new Set(filters.modifierIds ?? []);
  return filterOrdersByProductMix(orders, filters).reduce((sum, order) => {
    return sum + getFilteredOrderItems(order, filters).reduce((itemSum, item) => {
      if (selectedModifierIds.size > 0) {
        const hasMatchingModifier = walkSelectedModifiers(item.modifiers, 1, item, false)
          .some(modifier => selectedModifierIds.has(modifier.modifierId));
        if (!hasMatchingModifier) {
          return itemSum;
        }
      }
      return itemSum + safeNumber(calculateOrderItemPrice(item));
    }, 0);
  }, 0);
};

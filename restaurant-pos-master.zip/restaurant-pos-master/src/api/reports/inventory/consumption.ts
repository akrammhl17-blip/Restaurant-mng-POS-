import {StringRecordId} from "surrealdb";
import {Tables} from "@/api/db/tables.ts";
import type {Order} from "@/api/model/order.ts";
import {fetchPaidOrders, SALES_SUMMARY_FETCHES} from "@/api/reports/sales/fetch.ts";
import {buildCreatedAtDateConditions, unwrapQueryResult} from "@/api/reports/shared/query.ts";
import {recordIdToString, recordToString} from "@/api/reports/shared/records.ts";
import type {DateRangeFilter, DbClient} from "@/api/reports/shared/types.ts";
import {getOrderItemDisplayUnitPrice} from "@/lib/order-item-display.ts";
import {calculateOrderNetSales} from "@/lib/order.ts";
import {toJsDate} from "@/lib/datetime.ts";
import {safeNumber} from "@/lib/utils.ts";
import {DateTime} from "luxon";
import {
  fetchLedgerMovements,
} from "@/lib/inventory/ledger.service.ts";

export type RecipeConsumptionItem = {
  id: string;
  name: string;
  code?: string;
  uom?: string;
  quantity: number;
  costAverage: number;
  costCurrent: number;
  saleAllocated: number;
  differenceAverage: number;
  differenceCurrent: number;
};

export type RecipeConsumptionOptions = DateRangeFilter & {
  dishIds?: string[];
  itemIds?: string[];
  limit?: number;
  /** When true, allocate sale price using inclusive display unit prices. */
  showInclusive?: boolean;
};

export type RecipeConsumptionSummary = {
  orderCount: number;
  byItem: RecipeConsumptionItem[];
  totals: {
    quantity: number;
    saleAllocated: number;
    costAverage: number;
    costCurrent: number;
    differenceAverage: number;
    differenceCurrent: number;
  };
};

type RecipeRow = {
  quantity?: number;
  cost?: number;
  item?: {
    id?: unknown;
    name?: string;
    code?: string;
    uom?: string;
    average_price?: number;
    price?: number;
  };
};

const normalizeKey = (id: unknown): string => {
  const str = recordIdToString(id) || String(id ?? "");
  const colon = str.lastIndexOf(":");
  return colon >= 0 ? str.slice(colon + 1) : str;
};

const loadRecipesByDish = async (
  db: DbClient,
  dishIds: string[],
): Promise<Map<string, RecipeRow[]>> => {
  const recipesMap = new Map<string, RecipeRow[]>();
  if (!dishIds.length) {
    return recipesMap;
  }

  await Promise.all(dishIds.map(async (dishId) => {
    try {
      const recipes = unwrapQueryResult<RecipeRow>(
        await db.query(
          `SELECT * FROM ${Tables.dishes_recipes} WHERE menu_item = $dishId FETCH item`,
          {dishId: new StringRecordId(dishId)},
        ),
      );
      if (recipes.length) {
        recipesMap.set(dishId, recipes);
      }
    } catch {
      // Skip dishes whose recipe fetch fails.
    }
  }));

  return recipesMap;
};

const collectDishIds = (orders: Order[], dishFilter: string[]): string[] => {
  const dishIds = new Set<string>();
  const filterSet = dishFilter.length ? new Set(dishFilter.map(normalizeKey)) : null;

  orders.forEach((order) => {
    order.items?.forEach((orderItem) => {
      if (!orderItem.item) {
        return;
      }
      const dishId = recordToString(orderItem.item);
      if (!dishId) {
        return;
      }
      if (filterSet && !filterSet.has(normalizeKey(dishId)) && !filterSet.has(dishId)) {
        return;
      }
      dishIds.add(dishId);
    });
  });

  return Array.from(dishIds);
};

/**
 * Theoretical consumption: recipe ingredient qty × sold (Paid) dish qty.
 * Does NOT use inventory issuance / ledger issues.
 */
export const getRecipeConsumptionSummary = async (
  db: DbClient,
  options: RecipeConsumptionOptions = {},
): Promise<RecipeConsumptionSummary> => {
  const {
    dishIds = [],
    itemIds = [],
    limit,
    showInclusive = false,
    ...dateRange
  } = options;

  const orders = await fetchPaidOrders(db, {
    ...dateRange,
    menuItemIds: dishIds,
    fetches: ["items", "items.item", "items.taxes", "items.tax_mode"],
  });

  const recipesMap = await loadRecipesByDish(db, collectDishIds(orders, dishIds));
  const itemFilter = itemIds.length
    ? new Set(itemIds.flatMap((id) => [id, normalizeKey(id)]))
    : null;

  const consumptionMap = new Map<string, RecipeConsumptionItem>();

  orders.forEach((order) => {
    order.items?.forEach((orderItem) => {
      const dish = orderItem.item;
      if (!dish) {
        return;
      }

      const dishId = recordToString(dish);
      if (dishIds.length) {
        const allowed = dishIds.some(
          (id) => id === dishId || normalizeKey(id) === normalizeKey(dishId),
        );
        if (!allowed) {
          return;
        }
      }

      const orderItemQuantity = safeNumber(orderItem.quantity);
      const orderItemSalePrice =
        orderItemQuantity * getOrderItemDisplayUnitPrice(orderItem, showInclusive);
      const recipes = recipesMap.get(dishId) || [];

      let totalRecipeCost = 0;
      const recipeCosts = new Map<string, number>();
      recipes.forEach((recipe) => {
        const inventoryItem = recipe.item;
        if (!inventoryItem) {
          return;
        }
        const itemId = recordToString(inventoryItem);
        const itemCost = safeNumber(recipe.quantity) * safeNumber(recipe.cost);
        recipeCosts.set(itemId, itemCost);
        totalRecipeCost += itemCost;
      });

      recipes.forEach((recipe) => {
        const inventoryItem = recipe.item;
        if (!inventoryItem) {
          return;
        }
        const itemId = recordToString(inventoryItem);
        if (itemFilter && !itemFilter.has(itemId) && !itemFilter.has(normalizeKey(itemId))) {
          return;
        }

        const consumedQuantity = orderItemQuantity * safeNumber(recipe.quantity);
        const averagePrice = safeNumber(inventoryItem.average_price || 0);
        const currentPrice = safeNumber(inventoryItem.price || 0);
        const costAverage = consumedQuantity * averagePrice;
        const costCurrent = consumedQuantity * currentPrice;
        const recipeCost = recipeCosts.get(itemId) || 0;
        const allocatedSalePrice = totalRecipeCost > 0
          ? (orderItemSalePrice * recipeCost) / totalRecipeCost
          : 0;

        let row = consumptionMap.get(itemId);
        if (!row) {
          row = {
            id: itemId,
            name: inventoryItem.name || "Unknown",
            code: inventoryItem.code,
            uom: inventoryItem.uom,
            quantity: 0,
            costAverage: 0,
            costCurrent: 0,
            saleAllocated: 0,
            differenceAverage: 0,
            differenceCurrent: 0,
          };
          consumptionMap.set(itemId, row);
        }

        row.quantity += consumedQuantity;
        row.costAverage += costAverage;
        row.costCurrent += costCurrent;
        row.saleAllocated += allocatedSalePrice;
      });
    });
  });

  let byItem = Array.from(consumptionMap.values()).map((item) => ({
    ...item,
    differenceAverage: item.saleAllocated - item.costAverage,
    differenceCurrent: item.saleAllocated - item.costCurrent,
  }));

  byItem.sort((a, b) => a.name.localeCompare(b.name));
  if (limit != null && limit > 0) {
    byItem = byItem
      .slice()
      .sort((a, b) => b.quantity - a.quantity)
      .slice(0, limit)
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  const totals = byItem.reduce(
    (acc, item) => {
      acc.quantity += item.quantity;
      acc.saleAllocated += item.saleAllocated;
      acc.costAverage += item.costAverage;
      acc.costCurrent += item.costCurrent;
      acc.differenceAverage += item.differenceAverage;
      acc.differenceCurrent += item.differenceCurrent;
      return acc;
    },
    {
      quantity: 0,
      saleAllocated: 0,
      costAverage: 0,
      costCurrent: 0,
      differenceAverage: 0,
      differenceCurrent: 0,
    },
  );

  return {
    orderCount: orders.length,
    byItem,
    totals,
  };
};

/**
 * Daily (or weekly/hourly) recipe-based consumption qty from Paid orders.
 */
export const getRecipeConsumptionTimeSeries = async (
  db: DbClient,
  options: DateRangeFilter & {granularity?: "daily" | "weekly" | "hourly"},
) => {
  const granularity = options.granularity ?? "daily";
  const orders = await fetchPaidOrders(db, {
    startDate: options.startDate,
    endDate: options.endDate,
    fetches: ["items", "items.item"],
  });

  const recipesMap = await loadRecipesByDish(db, collectDishIds(orders, []));
  const buckets = new Map<string, number>();

  const bucketKey = (date: DateTime) => {
    if (granularity === "hourly") {
      return date.toFormat("yyyy-LL-dd HH:00");
    }
    if (granularity === "weekly") {
      return date.startOf("week").toISODate() ?? date.toISODate() ?? "";
    }
    return date.toISODate() ?? "";
  };

  orders.forEach((order) => {
    const jsDate = toJsDate(order.created_at as Parameters<typeof toJsDate>[0]);
    const key = bucketKey(DateTime.fromJSDate(jsDate));
    let dayQty = 0;

    order.items?.forEach((orderItem) => {
      const dish = orderItem.item;
      if (!dish) {
        return;
      }
      const dishId = recordToString(dish);
      const recipes = recipesMap.get(dishId) || [];
      const orderItemQuantity = safeNumber(orderItem.quantity);
      recipes.forEach((recipe) => {
        if (!recipe.item) {
          return;
        }
        dayQty += orderItemQuantity * safeNumber(recipe.quantity);
      });
    });

    buckets.set(key, (buckets.get(key) ?? 0) + dayQty);
  });

  return Array.from(buckets.entries())
    .map(([period, value]) => ({period, value}))
    .sort((a, b) => a.period.localeCompare(b.period));
};

/**
 * Actual stock issuance from ledger (issues + buffet consumption).
 * Distinct from theoretical recipe consumption.
 */
export const getIssuanceSummary = async (
  db: DbClient,
  options: DateRangeFilter & {limit?: number} = {},
) => {
  const limit = options.limit ?? 50;
  // business_date is yyyy-MM-dd; strip time from report filter date-times
  const toBiz = (value?: string) => {
    if (!value?.trim()) return undefined;
    const trimmed = value.trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;
    if (/^\d{4}-\d{2}-\d{2}/.test(trimmed)) return trimmed.slice(0, 10);
    return trimmed;
  };
  // Include reversals so we can detect and exclude voided originals.
  const movements = await fetchLedgerMovements(db as any, {
    from: toBiz(options.startDate),
    to: toBiz(options.endDate),
    referenceTypes: ["issue", "buffet_consumption"],
    excludeReversals: false,
  });

  // Build a set of original ledger row IDs that have been reversed (voided).
  const voidedOriginalIds = new Set<string>();
  movements.forEach((row) => {
    if (row.reversal_of) {
      voidedOriginalIds.add(row.reversal_of);
    }
  });

  // Exclude both reversal entries and the original rows they reverse.
  const activeMovements = movements.filter(
    (row) => !row.reversal_of && !voidedOriginalIds.has(row.id),
  );

  const items = unwrapQueryResult<{id: unknown; name?: string}>(
    await db.query(`SELECT id, name FROM ${Tables.inventory_items}`),
  );
  const itemMetaByKey = new Map<string, {id: string; name: string}>();
  items.forEach((item) => {
    const full = recordToString(item.id);
    const meta = {id: full, name: item.name ?? "Unknown"};
    itemMetaByKey.set(full, meta);
    itemMetaByKey.set(normalizeKey(full), meta);
  });

  const byItem = new Map<string, {itemId: string; name: string; quantity: number}>();
  activeMovements.forEach((row) => {
    const meta =
      itemMetaByKey.get(row.inventory_item)
      || itemMetaByKey.get(normalizeKey(row.inventory_item));
    const itemId = meta?.id || row.inventory_item;
    const name = meta?.name || "Unknown";
    const key = normalizeKey(itemId);
    const existing = byItem.get(key) || {itemId, name, quantity: 0};
    existing.quantity += Math.abs(safeNumber(row.quantity_change));
    byItem.set(key, existing);
  });

  return {
    type: "issue" as const,
    movementCount: activeMovements.length,
    byItem: Array.from(byItem.values()).sort((a, b) => b.quantity - a.quantity).slice(0, limit),
  };
};

const documentLineCost = (docs: Array<{items?: Array<{quantity?: number; price?: number}>}>) =>
  docs.reduce((sum, doc) => {
    return sum + (doc.items || []).reduce((itemSum, item) => {
      return itemSum + safeNumber(item.quantity) * safeNumber(item.price);
    }, 0);
  }, 0);

export type SaleVsConsumptionItemRow = {
  itemId: string;
  name: string;
  code?: string;
  uom?: string;
  purchasedQty: number;
  purchasedCost: number;
  issuedQty: number;
  issuedCost: number;
  consumedQty: number;
  consumedCost: number;
  qtyVariance: number;
  costVariance: number;
};

type DocLineItem = {
  quantity?: number;
  price?: number;
  item?: {
    id?: unknown;
    name?: string;
    code?: string;
    uom?: string;
    average_price?: number;
  } | string | null;
};

type DocWithLines = {items?: DocLineItem[]};

type ItemAgg = {
  itemId: string;
  name: string;
  code?: string;
  uom?: string;
  averagePrice: number;
  purchasedQty: number;
  purchasedCost: number;
  issuedQty: number;
  issuedCost: number;
  consumedQty: number;
};

const accumulateDocLines = (
  docs: DocWithLines[],
  target: Map<string, ItemAgg>,
  kind: "purchase" | "issue",
) => {
  docs.forEach((doc) => {
    (doc.items || []).forEach((line) => {
      const rawItem = line.item;
      if (!rawItem || typeof rawItem === "string") return;
      const itemId = recordToString(rawItem.id ?? rawItem);
      if (!itemId) return;
      const key = normalizeKey(itemId);
      const qty = safeNumber(line.quantity);
      const cost = qty * safeNumber(line.price);
      let row = target.get(key);
      if (!row) {
        row = {
          itemId,
          name: rawItem.name || "Unknown",
          code: rawItem.code,
          uom: rawItem.uom,
          averagePrice: safeNumber(rawItem.average_price),
          purchasedQty: 0,
          purchasedCost: 0,
          issuedQty: 0,
          issuedCost: 0,
          consumedQty: 0,
        };
        target.set(key, row);
      } else {
        if (!row.code && rawItem.code) row.code = rawItem.code;
        if (!row.uom && rawItem.uom) row.uom = rawItem.uom;
        if (!row.averagePrice && rawItem.average_price != null) {
          row.averagePrice = safeNumber(rawItem.average_price);
        }
      }
      if (kind === "purchase") {
        row.purchasedQty += qty;
        row.purchasedCost += cost;
      } else {
        row.issuedQty += qty;
        row.issuedCost += cost;
      }
    });
  });
};

/**
 * Sale vs Consumption report totals + per-item purchase / issue / theoretical consumption.
 */
export const getSaleVsConsumptionReport = async (
  db: DbClient,
  options: DateRangeFilter & {limit?: number} = {},
) => {
  const limit = options.limit;
  const {conditions, params} = buildCreatedAtDateConditions(options);

  const [orders, issues, purchases, consumption] = await Promise.all([
    fetchPaidOrders(db, {
      ...options,
      fetches: SALES_SUMMARY_FETCHES,
    }),
    unwrapQueryResult<DocWithLines>(
      await db.query(
        `SELECT * FROM ${Tables.inventory_issues}
         ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
         FETCH items, items.item`,
        params,
      ),
    ),
    unwrapQueryResult<DocWithLines>(
      await db.query(
        `SELECT * FROM ${Tables.inventory_purchases}
         ${conditions.length ? `WHERE ${conditions.join(" AND ")}` : ""}
         FETCH items, items.item`,
        params,
      ),
    ),
    getRecipeConsumptionSummary(db, options),
  ]);

  const saleTotal = orders.reduce((sum, order) => sum + calculateOrderNetSales(order), 0);
  const consumptionTotal = consumption.totals.costAverage;
  const issuanceTotal = documentLineCost(issues);
  const purchaseTotal = documentLineCost(purchases);

  const consumptionProfit = saleTotal - consumptionTotal;
  const issuanceProfit = saleTotal - issuanceTotal;
  const purchaseProfit = saleTotal - purchaseTotal;

  const byKey = new Map<string, ItemAgg>();
  accumulateDocLines(purchases, byKey, "purchase");
  accumulateDocLines(issues, byKey, "issue");

  consumption.byItem.forEach((item) => {
    const key = normalizeKey(item.id);
    let row = byKey.get(key);
    if (!row) {
      row = {
        itemId: item.id,
        name: item.name,
        code: item.code,
        uom: item.uom,
        averagePrice: item.quantity > 0 ? item.costAverage / item.quantity : 0,
        purchasedQty: 0,
        purchasedCost: 0,
        issuedQty: 0,
        issuedCost: 0,
        consumedQty: 0,
      };
      byKey.set(key, row);
    } else {
      if (!row.code && item.code) row.code = item.code;
      if (!row.uom && item.uom) row.uom = item.uom;
      if (!row.averagePrice && item.quantity > 0) {
        row.averagePrice = item.costAverage / item.quantity;
      }
    }
    row.consumedQty += item.quantity;
  });

  let byItem: SaleVsConsumptionItemRow[] = Array.from(byKey.values()).map((row) => {
    const periodUnit =
      row.purchasedQty > 0 ? row.purchasedCost / row.purchasedQty : row.averagePrice;
    const consumedCost = row.consumedQty * periodUnit;
    return {
      itemId: row.itemId,
      name: row.name,
      code: row.code,
      uom: row.uom,
      purchasedQty: row.purchasedQty,
      purchasedCost: row.purchasedCost,
      issuedQty: row.issuedQty,
      issuedCost: row.issuedCost,
      consumedQty: row.consumedQty,
      consumedCost,
      qtyVariance: row.issuedQty - row.consumedQty,
      costVariance: row.issuedCost - consumedCost,
    };
  });

  byItem.sort((a, b) => {
    const varCmp = Math.abs(b.qtyVariance) - Math.abs(a.qtyVariance);
    if (varCmp !== 0) return varCmp;
    return b.consumedQty - a.consumedQty;
  });

  if (limit != null && limit > 0) {
    byItem = byItem.slice(0, limit);
  }

  return {
    saleTotal,
    consumptionTotal,
    consumptionProfit,
    consumptionProfitPercent: saleTotal > 0 ? (consumptionProfit / saleTotal) * 100 : 0,
    issuanceTotal,
    issuanceProfit,
    issuanceProfitPercent: saleTotal > 0 ? (issuanceProfit / saleTotal) * 100 : 0,
    purchaseTotal,
    purchaseProfit,
    purchaseProfitPercent: saleTotal > 0 ? (purchaseProfit / saleTotal) * 100 : 0,
    byItem,
    orderCount: orders.length,
  };
};
